//Set credit limit to 50000 
function SetCreditLimitDefault()
{
	//Check if field is available or not
	if(Xrm.Page.getAttribute("creditlimit")!=null)
	 //Call method from common library
	 HIMBAP.CommonScripts.setDefaultValue("creditlimit",50000);
}