//To validate dates
    function validateProposedDates() {
	    HIMBAP.CommonScripts.ValidateProposedDates("him_proposedstart","him_proposedend");
	}