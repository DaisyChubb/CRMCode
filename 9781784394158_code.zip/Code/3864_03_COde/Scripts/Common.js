//Create namespace for HIMBAP library
if (typeof (HIMBAP) == "undefined")
{ HIMBAP = { __namespace: true }; }

//Common methods for 
HIMBAP.CommonScripts = {
//Method to set default field value
SetDefaultValue: function(fieldName,defaultValue)
{
	//Check if field is available or not
	if(Xrm.Page.getAttribute(fieldName)!=null)
		//Set value
		Xrm.Page.getAttribute(fieldName).setValue(defaultValue);
},
ValidateProposedDates:function(startDate,endDate) {
	    if(Xrm.Page.getAttribute(startDate)!=null && 
		Xrm.Page.getAttribute(startDate).getValue()!=null &&
		Xrm.Page.getAttribute(endDate)!=null && 
		Xrm.Page.getAttribute(endDate).getValue()!=null)
		{
	    var startDateValue = Xrm.Page.getAttribute(startDate).getValue();
        var endDateValue = Xrm.Page.getAttribute(endDate).getValue();
            if (startDateValue > endDateValue) {
                alert("End Date Should be greater than Start Date")
                Xrm.Page.getAttribute(endDate).setValue("");
				//Set focus on end date field
				Xrm.Page.getControl(endDate).setFocus()
            }
        }
	},
FilterLookup:function(LookupControl,Filter)
{
	if(Xrm.Page.getControl(LookupControl)!=null)
	{
		Xrm.Page.getControl(LookupControl).addPreSearch(function(){
			Xrm.Page.getControl(LookupControl).addCustomFilter(Filter);
		});
	}

},

 __namespace: true
};

