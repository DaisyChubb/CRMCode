//to filter trainer lookup
function AddLookupFilter()
{
 HIMBAP.CommonScripts.FilterLookup("him_trainer","<filter type='and'><condition attribute='new_contacttype' operator='eq' value='100000001'/></filter>");
}