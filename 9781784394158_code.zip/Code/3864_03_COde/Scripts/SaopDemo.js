function GetClientInformation(id) {
		//get server URL
			   var id=Xrm.Page.getAttribute("parentcustomerid").getValue()[0].id;
			   var clientUrl = Xrm.Page.context.getClientUrl();
			   //set organization service URL
			   var ServerURL=clientUrl + "/XRMServices/2011/Organization.svc/web";
			   var requestMain = ""
               requestMain += "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">";
               requestMain += "  <s:Body>";
               requestMain += "    <Retrieve xmlns=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">";
               requestMain += "      <entityName>account</entityName>";
               requestMain += "      <id>"+id+"</id>";
               requestMain += "      <columnSet xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\">";
               requestMain += "        <a:AllColumns>false</a:AllColumns>";
               requestMain += "        <a:Columns xmlns:b=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">";
               requestMain += "          <b:string>name</b:string>";
               requestMain += "          <b:string>address1_line1</b:string>";
               requestMain += "          <b:string>address1_line2</b:string>";
               requestMain += "          <b:string>address1_city</b:string>";
               requestMain += "          <b:string>address1_country</b:string>";
               requestMain += "          <b:string>address1_postalcode</b:string>";
               requestMain += "          <b:string>address1_stateorprovince</b:string>";
               requestMain += "        </a:Columns>";
               requestMain += "      </columnSet>";
               requestMain += "    </Retrieve>";
               requestMain += "  </s:Body>";
               requestMain += "</s:Envelope>";
               var req = new XMLHttpRequest();
               req.open("POST", ServerURL, true)
               // Responses will return XML. It isn't possible to return JSON.
               req.setRequestHeader("Accept", "application/xml, text/xml, */*");
               req.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
               req.setRequestHeader("SOAPAction", "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Retrieve");
               req.onreadystatechange = function () { successCallback(req); };
               req.send(requestMain);
           }
		function successCallback(req) {
               if (req.readyState == 4) {
				   if (req.status == 200) {
				   var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async = "false";
					xmlDoc.loadXML(req.responseXML.xml);
				    var KeyValuePairs=xmlDoc.getElementsByTagName("a:KeyValuePairOfstringanyType");
					
					//clear address fields
					Xrm.Page.getAttribute("address1_line1").setValue(null);
					Xrm.Page.getAttribute("address1_line2").setValue(null);
					Xrm.Page.getAttribute("address1_city").setValue(null);
					Xrm.Page.getAttribute("address1_stateorprovince").setValue(null);
					Xrm.Page.getAttribute("address1_postalcode").setValue(null);
					//traverse resultset					
					for(i=0; i<KeyValuePairs.length; i++)
					{
					if(KeyValuePairs[i].childNodes[0].text=="address1_line1")
					Xrm.Page.getAttribute("address1_line1").setValue(KeyValuePairs[i].childNodes[1].text);
					if(KeyValuePairs[i].childNodes[0].text=="address1_line2")
					Xrm.Page.getAttribute("address1_line2").setValue(KeyValuePairs[i].childNodes[1].text);
					if(KeyValuePairs[i].childNodes[0].text=="address1_city")
					Xrm.Page.getAttribute("address1_city").setValue(KeyValuePairs[i].childNodes[1].text);
					if(KeyValuePairs[i].childNodes[0].text=="address1_stateorprovince")
					Xrm.Page.getAttribute("address1_stateorprovince").setValue(KeyValuePairs[i].childNodes[1].text);
					if(KeyValuePairs[i].childNodes[0].text=="address1_postalcode")
					Xrm.Page.getAttribute("address1_postalcode").setValue(KeyValuePairs[i].childNodes[1].text);
					}
				   }
				   else {
					   alert("Error while retrieving client record");
				   }
           }
       }
      
