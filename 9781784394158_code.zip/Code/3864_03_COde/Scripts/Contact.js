//Get client details
function GetClientID()
{
	if(Xrm.Page.getAttribute("parentcustomerid")!=null &&
	Xrm.Page.getAttribute("parentcustomerid").getValue()!=null)
	{
		var clientID=Xrm.Page.getAttribute("parentcustomerid").getValue()[0].id;
		PopulateAddressInformationBasedOnAccount(clientID);
	}
}

function PopulateAddressInformationBasedOnAccount(clientID)
{
	//get server URL
	var clientUrl = Xrm.Page.context.getClientUrl();
	//set organization service URL
	var odataPath=clientUrl + "/XRMServices/2011/OrganizationData.svc/";
	var type="AccountSet";
    var req = new XMLHttpRequest();
	req.open("GET", odataPath + type + "(guid'" + clientID + "')", true);
	req.setRequestHeader("Accept", "application/json");
	req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
	req.onreadystatechange = function () {
	if (this.readyState == 4 /* complete */) {
		req.onreadystatechange = null;
		if (this.status == 200) {
		successCallback(JSON.parse(this.responseText).d);
    }
    else {
		alert("Error while fetching client data");
    }
   }
  };
  req.send();
 }
function successCallback(ResultSet)
{
	Xrm.Page.getAttribute("address1_line1").setValue(ResultSet.Address1_Line1!=null?ResultSet.Address1_Line1:null);
	Xrm.Page.getAttribute("address1_line2").setValue(ResultSet.Address1_Line2!=null?ResultSet.Address1_Line2:null);
	Xrm.Page.getAttribute("address1_city").setValue(ResultSet.Address1_City!=null?ResultSet.Address1_City:null);
	Xrm.Page.getAttribute("address1_country").setValue(ResultSet.Address1_Country!=null?ResultSet.Address1_Country:null);
	Xrm.Page.getAttribute("address1_stateorprovince").setValue(ResultSet.Address1_StateOrProvience!=null?ResultSet.Address1_StateOrProvience:null);
	Xrm.Page.getAttribute("address1_postalcode").setValue(ResultSet.Address1_PostalCode!=null?ResultSet.Address1_PostalCode:null);
}
